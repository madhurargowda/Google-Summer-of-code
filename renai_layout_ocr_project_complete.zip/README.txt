RenAIssance Layout OCR Project
--------------------------------
This project performs layout detection on historical Spanish documents.
Model used: YOLOv8 (convolutional-based)
Task: Identify regions containing main text while ignoring embellishments.
Outputs include: Detected layout images, OCR results, and sample dataset files.
